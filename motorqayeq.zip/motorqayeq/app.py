import streamlit as st
import sqlite3
import os
from streamlit_option_menu import option_menu
import streamlit.components.v1 as components




st.set_page_config(
    page_title="موتور قایق مالک",
    page_icon="static/logo.png",
    layout="wide",
    initial_sidebar_state="expanded",
)






db_path = os.path.join('/app/media-storage', 'media.db')


# db_path = os.path.join('media.db')

# ایجاد پایگاه داده
def create_database():

    

    conn = sqlite3.connect(db_path)
    c = conn.cursor()
    c.execute('''
        CREATE TABLE IF NOT EXISTS media (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            video BLOB,
            image BLOB,
            text TEXT
        )
    ''')
    conn.commit()
    conn.close()

# ایجاد جدول نظرات
def create_comments_table():
    conn = sqlite3.connect(db_path)
    c = conn.cursor()
    c.execute('''
        CREATE TABLE IF NOT EXISTS comments (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            comment TEXT NOT NULL,
            approved BOOLEAN NOT NULL DEFAULT 0,
            response TEXT
        )
    ''')
    conn.commit()
    conn.close()

# ذخیره رسانه در پایگاه داده
def save_to_database(video, image, text):
    conn = sqlite3.connect(db_path)
    c = conn.cursor()
    c.execute("INSERT INTO media (video, image, text) VALUES (?, ?, ?)", (video, image, text))
    conn.commit()
    conn.close()

# دریافت رسانه‌ها از پایگاه داده
def get_media():
    conn = sqlite3.connect(db_path)
    c = conn.cursor()
    c.execute("SELECT * FROM media ORDER BY id DESC")
    data = c.fetchall()
    conn.close()
    return data

# حذف رسانه از پایگاه داده
def delete_media(media_id):
    conn = sqlite3.connect(db_path)
    c = conn.cursor()
    c.execute("DELETE FROM media WHERE id = ?", (media_id,))
    conn.commit()
    conn.close()

# ذخیره نظر کاربر
def save_comment(name, comment):
    conn = sqlite3.connect(db_path)
    c = conn.cursor()
    c.execute("INSERT INTO comments (name, comment) VALUES (?, ?)", (name, comment))
    conn.commit()
    conn.close()

# دریافت نظرات از پایگاه داده
def get_comments():
    conn = sqlite3.connect(db_path)
    c = conn.cursor()
    c.execute("SELECT * FROM comments ORDER BY id DESC")
    data = c.fetchall()
    conn.close()
    return data

# تأیید نظر کاربر
def approve_comment(comment_id, response):
    conn = sqlite3.connect(db_path)
    c = conn.cursor()
    c.execute("UPDATE comments SET approved = 1, response = ? WHERE id = ?", (response, comment_id))
    conn.commit()
    conn.close()

# حذف نظر کاربر
def delete_comment(comment_id):
    conn = sqlite3.connect(db_path)
    c = conn.cursor()
    c.execute("DELETE FROM comments WHERE id = ?", (comment_id,))
    conn.commit()
    conn.close()

create_database()
create_comments_table()











with open("static/c.css") as f:
    st.markdown(f"<style> {f.read()} </style>", unsafe_allow_html=True)

# Streamlit interface
selected_option = option_menu(
    menu_title=None,
    options=["تماس با من", "بازی کن", "نظرات", "ورود ادمین", "خانه"],
    icons=["phone", "", "", "key", "house"],
    menu_icon="cast",
    default_index=4,
    orientation="horizontal",
    styles={
        "container": {"background-color": "#ffffff"},
        "icon": {"color": "#000000"},
        "nav-link-selected": {"background-color": "#056bb7"},
        "nav-link": {"color": "#000000", "font-size": "19px", "text-align": "center_y: 0.0", "margin": "0px", "--hover-color": "#4eb0fa"},
    }
)

st.write(" 🛥 تعمیرگاه تخصصی موتور قایق مالک 🛥 ")

if selected_option == "نظرات":
    # بخش نظرات کاربران
    st.subheader("نظرات کاربران")
    st.divider()
    name = st.text_input("نام خود را وارد کنید")
    user_comment = st.text_area("نظر خود را بنویسید")
    if st.button("ارسال", key="submit_comment"):
        if name and user_comment:
            save_comment(name, user_comment)
            st.success("نظر شما با موفقیت ارسال شد!")
            st.divider()
        else:
            st.error("لطفا نام و نظر خود را وارد کنید.")

            

    # نمایش نظرات تأیید شده
    comments = get_comments()
    for index, comment in enumerate(comments):
        if comment[3] == 1:  # اگر تأیید شده باشد
            st.write(f"**{comment[1]}**: {comment[2]}")  # نام و نظر
            st.write(f"**پاسخ ادمین**: {comment[4]}")  # پاسخ ادمین
            st.divider()

elif selected_option == "ورود ادمین":
    admin_password = st.text_input("ورود ادمین", type="password")
    b = st.button("ورود", key="admin_login")

    if admin_password == "malek":
        tab1, tab2 = st.tabs(["فایل", "نظرات"])

        with tab1:
            st.success("خوش آمدید مالک")

            # تب بارگذاری رسانه
            media_type = st.selectbox("Select Media Type", options=["ویدیو", "تصاویر"])
            if media_type == "ویدیو":
                uploaded_file = st.file_uploader("Upload Video", type=["mp4", "mov", "avi"])
            else:
                uploaded_file = st.file_uploader("Upload Image", type=["jpg", "jpeg", "png"])

            text_input = st.text_area("Enter Description")

            if st.button("Save", key="save_media"):
                if uploaded_file is not None and text_input:
                    media_data = uploaded_file.read()
                    if media_type == "ویدیو":
                        save_to_database(media_data, None, text_input)  # ذخیره ویدیو
                    else:
                        save_to_database(None, media_data, text_input)  # ذخیره تصویر
                    st.success(f"{media_type} و متن با موفقیت ذخیره شد!")

                else:
                    st.error("لطفا یک فایل و یک توضیح وارد کنید.")

            # نمایش رسانه‌های بارگذاری شده
            st.subheader("رسانه‌های بارگذاری شده")
            st.divider()
            media = get_media()
            for media_item in media:
                if media_item[1]:  # بررسی وجود ویدیو
                    st.video(media_item[1])  # نمایش ویدیو
                if media_item[2]:  # بررسی وجود تصویر
                    st.image(media_item[2], use_container_width=True)  # نمایش تصویر
                st.write(media_item[3])  # نمایش متن
                if st.button(f"حذف رسانه {media_item[0]}", key=f"delete_media_{media_item[0]}"):
                    delete_media(media_item[0])
                    st.success(f"رسانه {media_item[0]} با موفقیت حذف شد!")
                    st.rerun()

                st.divider()

        with tab2:
            st.subheader("مدیریت نظرات کاربران")
            st.divider()
            comments = get_comments()
            for comment in comments:
                st.write(f"**{comment[1]}**: {comment[2]}")  # نام و نظر
                if comment[3] == 0:  # اگر تأیید نشده است
                    admin_response = st.text_area(f"پاسخ به {comment[1]}", key=f"response_{comment[0]}")
                    
                    if st.button(f"تایید نظر {comment[1]}", key=f"approve_comment_{comment[0]}"):
                        # ارسال نظر به همراه پاسخ (خالی یا پر)
                        approve_comment(comment[0], admin_response if admin_response else "")
                        st.success(f"نظر {comment[1]} تایید شد!")
                        st.rerun()  # رفرش صفحه برای نمایش تغییرات
                        
                else:
                    st.write(f"**پاسخ ادمین**: {comment[4]}")  # پاسخ ادمین

                if st.button(f"حذف نظر {comment[1]}", key=f"delete_comment_{comment[0]}"):
                    delete_comment(comment[0])
                    st.success(f"نظر {comment[1]} حذف شد!")
                    st.rerun()  # رفرش صفحه برای نمایش تغییرات

                st.divider()

    else:
        st.warning("لطفا رمز عبور خود را وارد کنید")

elif selected_option == "خانه":
    # نمایش همه رسانه‌ها برای دسترسی عمومی
    with st.expander("موتور قایق مالک", expanded=True):
        st.image("static/m.jpg")
        st.write("""
        تعمیرگاه انواع موتورهای دریایی دو زمانه و چهار زمانه و تعمیرات گیربکس و پمپ هیدرولیک جک موتور قایق
        """)
        st.image("static/logo.png",width=100)
        st.divider()

        st.text("""
تعمیرگاه انواع موتورهای دریایی، شامل موتورهای دو زمانه و چهار زمانه، به عنوان یک مرکز تخصصی برای ارائه خدمات تعمیر و نگهداری به قایق‌ها و شناورهای دریایی فعالیت می‌کند. در اینجا به توضیحات بیشتری در مورد هر یک از این موارد می‌پردازیم:
1. موتورهای دریایی دو زمانه و چهار زمانه:

موتورهای دو زمانه:

این نوع موتورها در هر دور چرخش خود، یک بار احتراق و تولید نیرو دارند. به همین دلیل، آن‌ها معمولاً سبک‌تر و ساده‌تر از موتورهای چهار زمانه هستند.
مزیت اصلی این موتورها، قدرت بالاتر در ابعاد کوچکتر و همچنین توانایی کار در شرایط مختلف است. با این حال، آن‌ها معمولاً مصرف سوخت بیشتری دارند و آلایندگی بیشتری نیز تولید می‌کنند.

موتورهای چهار زمانه:

این موتورها برای تولید نیرو به چهار مرحله احتراق نیاز دارند: مکش، فشرده‌سازی، احتراق و تخلیه. این فرایند باعث می‌شود که این موتورها به طور کلی کارآمدتر و با آلایندگی کمتری نسبت به موتورهای دو زمانه عمل کنند.
آن‌ها معمولاً دارای عمر طولانی‌تری هستند و در شرایط مختلف دریایی عملکرد بهتری دارند.

2. تعمیرات گیربکس:

گیربکس‌ها به عنوان واسط بین موتور و پروانه قایق عمل می‌کنند و وظیفه انتقال نیروی موتور به پروانه را بر عهده دارند. تعمیرات گیربکس شامل بررسی و تعویض روغن، تعمیر یا تعویض دنده‌ها و بلبرینگ‌ها و همچنین تنظیمات لازم برای بهینه‌سازی عملکرد گیربکس است.

3. پمپ هیدرولیک:

پمپ‌های هیدرولیک در قایق‌ها برای تأمین نیروی لازم برای سیستم‌های هیدرولیکی مانند جک‌ها و فرمان‌های هیدرولیک استفاده می‌شوند. تعمیرات این پمپ‌ها شامل بررسی نشتی‌ها، تعویض قطعات فرسوده و تنظیم فشار پمپ می‌باشد.

4. جک موتور قایق:

جک‌های موتور به عنوان سیستم‌های هیدرولیکی برای تنظیم ارتفاع و زاویه موتور قایق عمل می‌کنند. تعمیرات این جک‌ها شامل بررسی و تعمیر نشتی‌ها، تعویض سیلندرها و اطمینان از عملکرد صحیح سیستم هیدرولیک است.

نتیجه‌گیری:
تعمیرگاه‌های تخصصی که به تعمیر و نگهداری انواع موتورهای دریایی، گیربکس‌ها و سیستم‌های هیدرولیکی می‌پردازند، نقش بسیار مهمی در حفظ عملکرد بهینه و ایمنی قایق‌ها و شناورها دارند. این تعمیرات نیاز به دانش فنی و تجربه کافی در زمینه موتورها و سیستم‌های هیدرولیکی دارد تا از بروز مشکلات جدی در دریا جلوگیری شود.
""")
        
    st.divider()

    media = get_media()
    for media_item in media:
        if media_item[1]:  # بررسی وجود ویدیو
            st.video(media_item[1])  # نمایش ویدیو
        if media_item[2]:  # بررسی وجود تصویر
            st.image(media_item[2], use_container_width=True)  # نمایش تصویر
        st.write(media_item[3])  # نمایش متن
    st.divider()

elif selected_option == "بازی کن":
    components.html("""
    <html><head><base href="https://websimgames.com/flappy-bird/" target="_blank"><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0"><title>بازی فلاپی پرنده</title>
    <style>
        body {
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            font-family: Arial, sans-serif;
        }
        #gameCanvas {
            border: 2px solid #fff;
            height: 210px;
        }
        #startScreen, #gameOverScreen {
            position: absolute;
            text-align: center;
            font-size: 14px;
            color: #fff;
            text-shadow: 2px 2px 4px #000;
            background-color: rgba(0,0,0,0.5);
            padding: 20px;
            border-radius: 10px;
        }
        #gameOverScreen {
            display: none;
        }
        button {
            font-size: 20px;
            padding: 10px 20px;
            margin-top: 10px;
            cursor: pointer;
        }
    </style>
    </head>
    <body>
    <canvas id="gameCanvas" width="288" height="312"></canvas>
    <div id="startScreen">
        <p>برای شروع بازی جوجه قشمی کلیک کنید</p>
    </div>
    <div id="gameOverScreen">
        <p>بازی تمام شد!</p>
        <p>امتیاز شما: <span id="finalScore"></span></p>
        <button id="restartButton">شروع مجدد</button>
    </div>

    <script>
    const canvas = document.getElementById('gameCanvas');
    const ctx = canvas.getContext('2d');
    const startScreen = document.getElementById('startScreen');
    const gameOverScreen = document.getElementById('gameOverScreen');
    const finalScoreElement = document.getElementById('finalScore');
    const restartButton = document.getElementById('restartButton');

    let bird = {
        x: 50,
        y: canvas.height / 2,
        velocity: 0,
        gravity: 0.5,
        lift: -7,
        size: 20
    };

    let pipes = [];
    let score = 0;
    let gameLoop;
    let gameStarted = false;

    // Load bird image
    const birdImg = new Image();
    birdImg.src = 'data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCA1MTIgNTEyIj48cGF0aCBmaWxsPSIjZmZkNzAwIiBkPSJNNDk2IDI1NmMwIDEzNi45LTExMS4xIDI0OC0yNDggMjQ4UzAgMzkyLjkgMCAyNTYgMTExLjEgOCAyNDggOHMyNDggMTExLjEgMjQ4IDI0OHoiLz48cGF0aCBmaWxsPSIjZmZhYTAwIiBkPSJNNDk2IDI1NmMwIDEzNi45LTExMS4xIDI0OC0yNDggMjQ4cy0yNDgtMTExLjEtMjQ4LTI0OEgzMTJsMTg0LTE4NHptLTI0OC0yNDh2MjQ4SDB6Ii8+PHBhdGggZmlsbD0iIzMzMyIgZD0iTTI0OCA1MmMtMTA4LjIgMC0xOTYgODcuOC0xOTYgMTk2czg3LjggMTk2IDE5NiAxOTYgMTk2LTg3LjggMTk2LTE5NlMzNTYuMiA1MiAyNDggNTJ6Ii8+PHBhdGggZmlsbD0iI2ZmZiIgZD0iTTMxMiAxOTJjMCAyNi41LTIxLjUgNDgtNDggNDhzLTQ4LTIyLjUtNDgtNDggMjEuNS00OCA0OC00OCA0OCAyMS41IDQ4IDQ4eiIvPjxwYXRoIGZpbGw9IiNmZmYiIGQ9Ik00MTYgMjA4YzAgOC44LTcuMiAxNi0xNiAxNmgtMzJjLTguOCAwLTE2LTcuMi0xNi0xNnM3LjItMTYgMTYtMTZoMzJjOC44IDAgMTYgNy4yIDE2IDE2eiIvPjxwYXRoIGZpbGw9IiNmZmYiIGQ9Ik0zODQgMjcyYzAgOC44LTcuMiAxNi0xNiAxNi0xNnM3LjItMTYgMTYtMTZoMzJjOC44IDAgMTYgNy4yIDE2IDE2eiIvPjxwYXRoIGZpbGw9IiNmZmYiIGQ9Ik0zNTIgMzM2YzAgOC44LTcuMiAxNi0xNiAxNi0xMTZyMTYgMTYtMTZoMzJjOC44IDAgMTYgNy4yIDE2IDE2eiIvPjwvc3ZnPg==';

    function drawBird() {
        ctx.save();
        ctx.translate(bird.x, bird.y);
        ctx.rotate(bird.velocity * 0.1);
        ctx.drawImage(birdImg, -bird.size / 2, -bird.size / 2, bird.size, bird.size);
        ctx.restore();
    }

    function drawPipes() {
        pipes.forEach(pipe => {
            ctx.fillStyle = '#00AA00';
            ctx.fillRect(pipe.x, 0, pipe.width, pipe.top);
            ctx.fillRect(pipe.x, canvas.height - pipe.bottom, pipe.width, pipe.bottom);
        });
    }

    function drawScore() {
        ctx.fillStyle = '#FFF';
        ctx.font = '24px Arial';
        ctx.fillText(`امتیاز: ${score}`, 10, 30);
    }

    function updateGame() {
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        
        bird.velocity += bird.gravity;
        bird.y += bird.velocity;
        
        if (bird.y + bird.size / 2 > canvas.height) {
            gameOver();
        }
        
        if (pipes.length === 0 || pipes[pipes.length - 1].x < canvas.width - 200) {
            let gap = 150;
            let pipeHeight = Math.floor(Math.random() * (canvas.height - gap - 100)) + 50;
            pipes.push({
                x: canvas.width,
                top: pipeHeight,
                bottom: canvas.height - pipeHeight - gap,
                width: 50,
                counted: false
            });
        }
        
        pipes.forEach(pipe => {
            pipe.x -= 2;
            
            if (pipe.x + pipe.width < 0) {
                pipes.shift();
            }
            
            if (
                bird.x + bird.size / 2 > pipe.x &&
                bird.x - bird.size / 2 < pipe.x + pipe.width &&
                (bird.y - bird.size / 2 < pipe.top || bird.y + bird.size / 2 > canvas.height - pipe.bottom)
            ) {
                gameOver();
            }
            
            if (pipe.x + pipe.width < bird.x && !pipe.counted) {
                score++;
                pipe.counted = true;
            }
        });
        
        drawPipes();
        drawBird();
        drawScore();
        
        if (gameStarted) {
            gameLoop = requestAnimationFrame(updateGame);
        }
    }

    function gameOver() {
        cancelAnimationFrame(gameLoop);
        gameStarted = false;
        finalScoreElement.textContent = score;
        gameOverScreen.style.display = 'block';
    }

    function resetGame() {
        bird.y = canvas.height / 2;
        bird.velocity = 0;
        pipes = [];
        score = 0;
        gameOverScreen.style.display = 'none';
        gameStarted = true;
        gameLoop = requestAnimationFrame(updateGame);
    }

    canvas.addEventListener('click', () => {
        if (gameStarted) {
            bird.velocity = bird.lift;
        }
    });

    startScreen.addEventListener('click', () => {
        startScreen.style.display = 'none';
        resetGame();
    });

    restartButton.addEventListener('click', resetGame);

    // Initial draw
    drawBird();
    </script>
    </body></html>
    """, height=500)

    st.markdown("[دیجی کد ( آموزش ساخت بازی و برنامه )](https://myket.ir/app/abdollah.digicode)")

elif selected_option == "تماس با من":
    st.write("آدرس : :red[قشم - رمکان]")
    st.write("شماره تماس : :red[09126506739]")







st.divider()
st.markdown("[طراحی شده توسط عبدالله چلاسی](https://abdollah-chelasi.hf.space/)")









st.markdown("""
<style> 
#MainMenu {visibility: hidden;}
footer {visibility: hidden;}
</style>
""", unsafe_allow_html=True)