import pathlib
from bs4 import BeautifulSoup
import shutil
import streamlit as st


def add_meta_tags():
    index_path = pathlib.Path(st.__file__).parent / "static" / "index.html"
    temp_index_path = index_path.with_name("temp_index.html") # مسیر فایل کپی

    # کپی کردن فایل index.html
    shutil.copy2(index_path, temp_index_path)
    
    soup = BeautifulSoup(temp_index_path.read_text(), features="html.parser")
    
    # تغییر عنوان
    title_tag = soup.new_tag('title')
    title_tag.string = 'تعمیرگاه تخصصی موتور قایق مالک'  # عنوان جدید
    soup.head.append(title_tag)

    # افزودن متا تگ‌های Open Graph
    og_tags = [
        ('og:title', 'تعمیرگاه تخصصی موتور قایق مالک'),
        ('og:description', 'تعمیرگاه انواع موتورهای دریایی دو زمانه و چهار زمانه و تعمیرات گیربکس و پمپ هیدرولیک جک موتور قایق'),
        ('og:image', 'https://motorqayeq.liara.run/media/f8644eff0a903c49d5a236916be006e42afb2f53c6752b991c1b1103.png'),
        ('og:url', 'https://motorqayeq.liara.run'),
        ('og:type', 'website'),
        ('telegram:card', 'summary_large_image')
    ]

    for name, content in og_tags:
        meta_tag = soup.new_tag('meta')
        meta_tag.attrs['property'] = name
        meta_tag.attrs['content'] = content
        soup.head.append(meta_tag)

    # افزودن متا تگ‌های سئو
    seo_tags = [
        ('description', 'تعمیرگاه انواع موتورهای دریایی دو زمانه و چهار زمانه و تعمیرات گیربکس و پمپ هیدرولیک جک موتور قایق'),
        ('keywords', 'تعمیرات جک موتور قایق, موتور قایق مالک , تعمرات گیربکس قشم , تعمیر موتور قایق قشم, موتور قایق قشم, مالک رمکان'),
        ('author', 'عبدالله چلاسی')
    ]

    for name, content in seo_tags:
        meta_tag = soup.new_tag('meta')
        meta_tag.attrs['name'] = name
        meta_tag.attrs['content'] = content
        soup.head.append(meta_tag)

    # اضافه کردن favicon
    favicon_tag = soup.new_tag('link')
    favicon_tag.attrs['rel'] = 'icon'
    favicon_tag.attrs['href'] = 'https://motorqayeq.liara.run/media/f8644eff0a903c49d5a236916be006e42afb2f53c6752b991c1b1103.png'  # آدرس لوگو
    favicon_tag.attrs['type'] = 'image/png'  # نوع تصویر
    soup.head.append(favicon_tag)

    # ذخیره تغییرات
    temp_index_path.write_text(str(soup))
    # جایگزینی فایل اصلی
    shutil.copy2(temp_index_path, index_path)
    # حذف فایل کپی
    temp_index_path.unlink()


# فراخوانی تابع
add_meta_tags()

